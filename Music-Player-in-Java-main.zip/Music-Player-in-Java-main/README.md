# Music-Player-in-Java
A Simple music player made in java using javax library. 

## Important
Add songs in wav format to the Songs folder before running code
